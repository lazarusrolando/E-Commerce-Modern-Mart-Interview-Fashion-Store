// JavaScript for Admin Dashboard

document.addEventListener('DOMContentLoaded', () => {
    const usersList = document.getElementById('usersList');
    if (!usersList) return; // Ensure usersList exists before proceeding

    let users = JSON.parse(localStorage.getItem('users') || '[]');
    console.log('Admin Name:', adminName); // Debugging line to check admin name


    // Display admin username
    const adminName = sessionStorage.getItem('adminName');
    console.log('Admin Name:', adminName); // Debugging line to check admin name

    if (adminName) {
        document.getElementById('dashboardAdmin').textContent = adminName;
    }

    function displayUsers(filteredUsers = users) {
        usersList.innerHTML = filteredUsers.map(user => `
            <div class="user-item" style="background: linear-gradient(90deg, #4c51bf, #6f7dff);">
                <div class="user-info">
                    <h4>${user.name}</h4>
                    <p>User ID: ${user.id}</p>
                    <p>Status: ${user.status}</p>
                </div>
            </div>
        `).join('');
    }

    function filterUsers(status) {
        const filteredUsers = status === 'all' ? users : users.filter(user => user.status === status);
        displayUsers(filteredUsers);
    }

    function searchUsers() {
        const searchTerm = document.getElementById('userSearch').value.toLowerCase();
        const filteredUsers = users.filter(user => user.name.toLowerCase().includes(searchTerm) || user.id.toString().includes(searchTerm));
        displayUsers(filteredUsers);
    }

    displayUsers();
});
