document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    // Handle User Login
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const emailOrUsername = document.getElementById('loginEmail').value;
            const password = document.getElementById('loginPassword').value;

            // Clear previous error messages
            document.getElementById('loginUsernameError').textContent = '';
            document.getElementById('loginPasswordError').textContent = '';

            if (!emailOrUsername || !password) {
                if (!emailOrUsername) {
                    document.getElementById('loginUsernameError').textContent = 'Please enter your username or email';
                }
                if (!password) {
                    document.getElementById('loginPasswordError').textContent = 'Please enter your password';
                }
                return;
            }

            const users = JSON.parse(localStorage.getItem('users')) || [];
            console.log('Users in localStorage:', users);
            console.log('Entered email/username:', emailOrUsername);

            // Find user by email or username
            const user = users.find(u => u.email === emailOrUsername || u.username === emailOrUsername);
            console.log('User found:', user);

            if (user && user.password === password) {
                console.log('Login successful');
                
                // Store login state and user information
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('username', user.username);
                localStorage.setItem('profileUsername', user.username);
                localStorage.setItem('userEmail', user.email);
                sessionStorage.setItem('loggedInUser', JSON.stringify(user));
                
                alert('Login successful! Redirecting to your dashboard...');

                // Check if there's a redirect URL
                const urlParams = new URLSearchParams(window.location.search);
                const redirectUrl = urlParams.get('redirect');
                
                // Redirect based on user type or redirect URL
                if (redirectUrl) {
                    window.location.href = decodeURIComponent(redirectUrl);
                } else if (user.isAdmin) {
                    window.location.href = 'admin-dashboard.html';
                } else {
                    window.location.href = 'user-dashboard.html';
                }
            } else {
                alert('Invalid username/email or password');
                document.getElementById('loginPasswordError').textContent = 'Invalid credentials';
            }
        });
    }

    // Handle User Registration
    const userRegisterForm = document.getElementById('userRegisterForm');
    if (userRegisterForm) {
        userRegisterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = userRegisterForm.querySelector('input[type="text"]').value; 
            const email = userRegisterForm.querySelector('input[type="email"]').value; 
            const password = userRegisterForm.querySelector('input[type="password"]').value;

            if (!username || !email || !password) {
                alert('Please fill in all fields');
                return;
            }

            // Create user object with plain password
            const user = {
                id: 'user-' + Date.now().toString(36) + Math.random().toString(36).substring(2),
                username: username,
                email: email,
                password: password,
                name: username,
                registered: new Date().toISOString(),
                lastLogin: null,
                isAdmin: false // Set default value for regular users
            };

            // Store user in localStorage
            const users = JSON.parse(localStorage.getItem('users')) || [];
            
            // Check if username or email already exists
            console.log('Checking for existing user...');
            const exists = users.some(u => u.username === username || u.email === email);
            if (exists) {
                console.log('User already exists with username/email:', username, email);
                alert('Username or email already exists');
                return;
            }
            
            console.log('User does not exist, creating new user...');
            users.push(user);
            localStorage.setItem('users', JSON.stringify(users));

            // Store user info for immediate login
            localStorage.setItem('isLoggedIn', 'true');
            localStorage.setItem('username', username);
            localStorage.setItem('profileUsername', username);
            localStorage.setItem('userEmail', email);
            sessionStorage.setItem('loggedInUser', JSON.stringify(user));

            alert('Registration successful! Redirecting to your dashboard...');

            const totalUsers = parseInt(localStorage.getItem('totalUsers') || '0');
            localStorage.setItem('totalUsers', (totalUsers + 1).toString());

            // Redirect to dashboard
            window.location.href = 'user-dashboard.html';
        });
    }
});
