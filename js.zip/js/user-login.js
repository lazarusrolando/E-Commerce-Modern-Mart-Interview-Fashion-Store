document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    // Handle User Login
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = loginForm.querySelector('input[type="email"]').value;
            const password = loginForm.querySelector('input[type="password"]').value;

            const users = JSON.parse(localStorage.getItem('users')) || [];
            console.log('Users in localStorage:', users);
            console.log('Entered email:', email);
            console.log('Entered password:', password);

            const user = users.find(u => u.email === email);
            console.log('User found:', user); // Log the found user for debugging

            if (user) {
                console.log('Comparing password...');
                if (password === user.password) {
                    console.log('Password match, logging in...');
                    sessionStorage.setItem('loggedInUser', JSON.stringify(user));
                    alert('Redirecting to ' + (user.isAdmin ? 'admin-dashboard.html' : 'user-dashboard.html'));

                    if (user.isAdmin) {
                        window.location.href = 'admin-dashboard.html';
                    } else {
                        window.location.href = 'user-dashboard.html';
                    }
                } else {
                    alert('Invalid credentials');
                }
            } else {
                alert('User not found');
            }
        });
    }

    // Handle User Registration
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = registerForm.querySelector('input[type="text"]').value; 
            const email = registerForm.querySelector('input[type="email"]').value; 
            const password = registerForm.querySelector('input[type="password"]').value;

            // Create user object with plain password
            const user = {
                id: 'user-' + Date.now().toString(36) + Math.random().toString(36).substr(2),
                username: username,
                email: email,
                password: password,
                name: username,
                registered: new Date().toISOString(),
                lastLogin: null,
                isAdmin: false // Set default value for regular users
            };

            // Store user in localStorage
            const users = JSON.parse(localStorage.getItem('users')) || [];
            
            // Check if username or email already exists
            console.log('Checking for existing user...');
            const exists = users.some(u => u.username === username || u.email === email);
            if (exists) {
                console.log('User already exists with username/email:', username, email);
                alert('Username or email already exists');
                return;
            }
            
            console.log('User does not exist, creating new user...');
            users.push(user);
            localStorage.setItem('users', JSON.stringify(users));

            alert('Registration successful! Your account has been created. Please login.');

            const totalUsers = parseInt(localStorage.getItem('totalUsers') || '0');
            localStorage.setItem('totalUsers', totalUsers + 1); // Update user statistics

            if (loginForm) {
                loginForm.querySelector('input[type="email"]').value = email;
                loginForm.querySelector('input[type="password"]').value = password;
            }
        });
    }
});
