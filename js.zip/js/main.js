import headerFunc from "./header.js"
import productFunc from "./product.js"
import searchFunc from "./search.js"

function checkUserLogin() {
    const user = JSON.parse(sessionStorage.getItem('loggedInUser'));
    return user ? user : { name: 'UserGuest' }; // Return guest if no user is logged in
}

function checkAdminLogin() {
    const admin = JSON.parse(sessionStorage.getItem('loggedInAdmin'))
    return admin ? admin : { name: 'AdminGuest' };
}

// Wishlist functionality
function initWishlist() {
    const wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];

    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('bi-heart-fill')) {
            const productCard = e.target.closest('.product-item');
            const product = {
                id: productCard.dataset.id,
                name: productCard.querySelector('.product-title').textContent,
                price: parseFloat(productCard.querySelector('.product-price').textContent.replace('&#x20B9;', '')),
                image: productCard.querySelector('.product-image').src
            };

            const existingIndex = wishlist.findIndex(item => item.id === product.id); // Check if product is already in wishlist
            if (existingIndex !== -1) {
                wishlist.splice(existingIndex, 1);
                e.target.classList.remove('active');
            } else {
                wishlist.push(product);
                e.target.classList.add('active');
            }

            localStorage.setItem('wishlist', JSON.stringify(wishlist));
        }
    });
}

// Initialize dashboard
function initDashboard() {
    const dashboardTabs = document.querySelectorAll('.dashboard-tab');
    dashboardTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            dashboardTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            const tabId = tab.getAttribute('data-tab');
            const tabContents = document.querySelectorAll('.tab-content');
            tabContents.forEach(content => content.classList.remove('active'));
            document.getElementById(`${tabId}Tab`).classList.add('active');
        });
    });
}

// Handle login
function handleLogin(event) {
    event.preventDefault();
    // Get username from form
    const username = document.querySelector('#loginForm input[name="username"]').value;

    // Store username in localStorage
    localStorage.setItem('username', username);

    // Update UI
    const userProfile = document.querySelector('.user-profile');
    if (userProfile) {
        const nameDisplay = document.createElement('span');
        nameDisplay.className = 'user-name';
        nameDisplay.textContent = username;
        userProfile.insertBefore(nameDisplay, userProfile.querySelector('img'));
    }
    const adminProfile = document.querySelector('.admin-profile');
    if (adminProfile) {
        const nameDisplay = document.createElement('span');
        nameDisplay.className = 'admin-name';
        nameDisplay.textContent = adminname;
        adminProfile.insertBefore(nameDisplay, adminProfile.querySelector('img'));
    }
    
    document.getElementById('userDashboard').style.display = 'block';
    document.querySelectorAll('.account-column').forEach(col => col.style.display = 'none');

    // Redirect to welcome page
    window.location.href = 'welcome.html'; // Redirect to the welcome page
}

// Handle registration
function handleRegister(event) {
    event.preventDefault();
    // Add registration logic here
    document.getElementById('userDashboard').style.display = 'block';
    document.querySelectorAll('.account-column').forEach(col => col.style.display = 'none');
}

// Initialize account functionality
function initAccount() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }

    initDashboard();
    initOrderHandling();
}

// Order handling functionality
function initOrderHandling() {
    // Handle add to cart button clicks
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('add-to-cart')) {
            const productCard = e.target.closest('.product-item');
            const product = {
                id: productCard.dataset.id,
                name: productCard.querySelector('.product-title').textContent,
                price: parseFloat(productCard.querySelector('.product-price').textContent.replace('₹', '')),
                image: productCard.querySelector('.product-image').src,
                quantity: 1,
                status: 'Pending'
            };

            // Get existing orders or create new array
            const orders = JSON.parse(localStorage.getItem('orders')) || []; // Get existing orders or create new array

            // Check if product already exists in orders
            const existingOrder = orders.find(order => order.id === product.id);
            if (existingOrder) {
                existingOrder.quantity += 1;
            } else {
                orders.push(product);
            }

            // Save updated orders
            localStorage.setItem('orders', JSON.stringify(orders));

            // Update cart count
            const cartItem = document.querySelector(".header-cart-count");
            if (cartItem) {
                cartItem.innerHTML = orders.reduce((sum, order) => sum + order.quantity, 0);
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    // Check user login and display name
    const user = checkUserLogin();
    const admin = checkAdminLogin();
    const userNameElement = document.getElementById('userName');
    const adminNameElement = document.getElementById('adminName');
    
    if (userNameElement) {
        userNameElement.textContent = user.name;
    }
    
    if (adminNameElement) {
        adminNameElement.textContent = admin.name;
    }
    // Display username if logged in
    const username = localStorage.getItem('username');
    const adminname = localStorage.getItem('adminname');
    if (username) {
        const userProfile = document.querySelector('.user-profile');
        if (userProfile) {
            const nameDisplay = document.createElement('span');
            nameDisplay.className = 'user-name';
            nameDisplay.textContent = username;
            userProfile.insertBefore(nameDisplay, userProfile.querySelector('img'));
        }
    }
    if (adminname) {
        const adminProfile = document.querySelector('.user-profile');
        if (adminProfile) {
            const nameDisplay = document.createElement('span');
            nameDisplay.className = 'admin-name';
            nameDisplay.textContent = adminname;
            userProfile.insertBefore(nameDisplay, adminProfile.querySelector('img'));
        }
    }

    initAccount();
    initWishlist();
});

//! add product to localstorage start

(async function () {
    const products = await fetch("js/data.json"); // Fetch product data
    const data = await products.json() // to json

    if (data) {
        localStorage.setItem("products", JSON.stringify(data)); // Store products in localStorage
    }
    productFunc(data)
    searchFunc(data)
})()

//! add product to localstorage end

//! add cartItem to localstorage start

const cartItem = document.querySelector(".header-cart-count"); // Select cart item count element


cartItem.innerHTML = localStorage.getItem("cart")
    ? JSON.parse(localStorage.getItem("cart")).length
    : "0"

//! add cartItem to localstorage end

//! modal dialog start

const modal = document.querySelector(".modal-dialog")
const modalContent = document.querySelector(".modal-dialog .modal-content")
const btnModalClose = document.querySelector(".modal-dialog .modal-close")

if (btnModalClose) {
    btnModalClose.addEventListener("click", () => {
        modal.classList.remove("show")
    })
}

if (modal) {
    document.addEventListener("click", (e) => {
        if (!e.composedPath().includes(modalContent)) {
            modal.classList.remove("show")
        }
    })
}

if (modal) {
    setTimeout(() => {
        modal.classList.add("show")
    }, 3000)
}

//! modal dialog end

// Profile Dropdown Interaction
document.addEventListener('DOMContentLoaded', function () {
    // Toggle profile dropdown
    const profile = document.querySelector('.user-profile');
    if (profile) {
        profile.addEventListener('click', function (e) {
            e.stopPropagation();
            const dropdown = this.querySelector('.dropdown');
            dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
        });
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function () {
        const dropdowns = document.querySelectorAll('.user-profile .dropdown');
        dropdowns.forEach(dropdown => {
            dropdown.style.display = 'none';
        });
    });

    // Profile Picture Upload
    const profilePictureInput = document.getElementById('profile-picture'); // Select profile picture input

    if (profilePictureInput) {
        profilePictureInput.addEventListener('change', function (e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    const img = document.querySelector('.profile-picture img');
                    img.src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        });
    }

    // Profile Form Submission
    const profileForm = document.querySelector('.profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', function (e) {
            e.preventDefault();
            // Add form submission logic here
            alert('Profile updated successfully!');
        });
    }

    // Settings Form Submission
    const settingsForm = document.querySelector('.settings-form'); // Select settings form

    if (settingsForm) {
        settingsForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const formData = new FormData(settingsForm);
            const settings = {
                storeName: formData.get('storeName'),
                currency: formData.get('currency'),
                paymentMethods: {
                    paypal: settingsForm.querySelector('input[type="checkbox"][value="paypal"]').checked,
                    stripe: settingsForm.querySelector('input[type="checkbox"][value="stripe"]').checked
                },
                security: {
                    twoFactor: formData.get('twoFactor'),
                    sessionTimeout: formData.get('sessionTimeout')
                }
            };

            // Save settings to localStorage
            localStorage.setItem('settings', JSON.stringify(settings));
            alert('Settings saved successfully!');
        });
    }

    // Active Navigation Link
    const currentPage = window.location.pathname.split('/').pop();
    const navLinks = document.querySelectorAll('.dashboard-header nav a');
    navLinks.forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });
});

// Initialize Font Awesome
(function () {
    const faScript = document.createElement('script');
    faScript.src = 'https://kit.fontawesome.com/your-fontawesome-kit.js';
    faScript.crossOrigin = 'anonymous';
    document.head.appendChild(faScript);
})();

// User Authentication Handler
function updateHeaderForUser() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const username = localStorage.getItem('username');
    const userLinks = document.querySelector('.header-right-links');

    if (userLinks) {
        if (isLoggedIn && username) {
            userLinks.innerHTML = `
                <div class="user-welcome">
                    <span>Welcome, ${username}</span>
                    <div class="user-menu">
                        <a href="user-dashboard.html">My Dashboard</a>
                        <a href="#" id="logout-btn">Logout</a>
                    </div>
                </div>
                <button class="search-button">
                    <i class="bi bi-search"></i>
                </button>
                <div class="header-wishlist">
                    <a href="wishlist.html" class="header-wishlist-link">
                        <i class="bi bi-heart"></i>
                        <span class="header-wishlist-count">0</span>
                    </a>
                </div>
                <div class="header-cart">
                    <a href="cart.html" class="header-cart-link">
                        <i class="bi bi-bag"></i>
                        <span class="header-cart-count">0</span>
                    </a>
                </div>
            `;

            // Add logout handler
            const logoutBtn = document.getElementById('logout-btn');
            if (logoutBtn) {
                logoutBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    localStorage.setItem('isLoggedIn', 'false');
                    localStorage.removeItem('username');
                localStorage.removeItem('adminName'); // Remove admin name on logout
                    window.location.href = '/index.html';
                });
            }
        } else {
            userLinks.innerHTML = ` 
                <a href="account.html">
                    <i class="bi bi-person"></i>Admin
                </a>
                <a href="user-account.html">
                    <i class="bi bi-person"></i>Login
                </a>
                <button class="search-button">
                    <i class="bi bi-search"></i>
                </button>
                <div class="header-wishlist">
                    <a href="wishlist.html" class="header-wishlist-link">
                        <i class="bi bi-heart"></i>
                        <span class="header-wishlist-count">0</span>
                    </a>
                </div>
                <div class="header-cart">
                    <a href="cart.html" class="header-cart-link">
                        <i class="bi bi-bag"></i>
                        <span class="header-cart-count">0</span>
                    </a>
                </div>
            `;
        }
    }
}

export function updateHeaderForAdmin() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const username = localStorage.getItem('username');
    const role = localStorage.getItem('role'); // Check role
    const userLinks = document.querySelector('.header-right-links');

    if (userLinks) {
        if (isLoggedIn && username) {
            if (role === 'admin') {
                // Admin-specific header
                userLinks.innerHTML = `
                    <div class="user-welcome">
                        <span>Welcome, ${username} (Admin)</span>
                        <div class="user-menu">
                            <a href="admin-dashboard.html">Admin Panel</a>
                            <a href="#" id="logout-btn">Logout</a>
                        </div>
                    </div>
                    <button class="search-button">
                        <i class="bi bi-search"></i>
                    </button>
                `;
            } else {
                // Regular user header
                userLinks.innerHTML = `
                    <div class="user-welcome">
                        <span>Welcome, ${username}</span>
                        <div class="user-menu">
                            <a href="user-dashboard.html">My Dashboard</a>
                            <a href="#" id="logout-btn">Logout</a>
                        </div>
                    </div>
                    <button class="search-button">
                        <i class="bi bi-search"></i>
                    </button>
                    <div class="header-wishlist">
                        <a href="wishlist.html" class="header-wishlist-link">
                            <i class="bi bi-heart"></i>
                            <span class="header-wishlist-count">0</span>
                        </a>
                    </div>
                    <div class="header-cart">
                        <a href="cart.html" class="header-cart-link">
                            <i class="bi bi-bag"></i>
                            <span class="header-cart-count">0</span>
                        </a>
                    </div>
                `;
            }
        } else {
            // Default (not logged in) header now shows the welcome message & menu
            userLinks.innerHTML = ` 
                <div class="user-welcome">
                    <span>Welcome, Guest</span>
                    <div class="user-menu">
                        <a href="admin-dashboard.html">My Dashboard</a>
                        <a href="#" id="logout-btn">Logout</a>
                    </div>
                </div>
                <button class="search-button">
                    <i class="bi bi-search"></i>
                </button>
                <div class="header-wishlist">
                    <a href="wishlist.html" class="header-wishlist-link">
                        <i class="bi bi-heart"></i>
                        <span class="header-wishlist-count">0</span>
                    </a>
                </div>
                <div class="header-cart">
                    <a href="cart.html" class="header-cart-link">
                        <i class="bi bi-bag"></i>
                        <span class="header-cart-count">0</span>
                    </a>
                </div>
            `;
        }

        // Add logout handler
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                localStorage.setItem('isLoggedIn', 'false');
                localStorage.removeItem('username');
                localStorage.removeItem('role'); // Remove role
                localStorage.removeItem('adminName'); // Ensure admin name is also removed
                window.location.href = '/index.html';
            });
        }
    }
}

// Call this when DOM loads
document.addEventListener('DOMContentLoaded', () => {
    updateHeaderForUser();
});