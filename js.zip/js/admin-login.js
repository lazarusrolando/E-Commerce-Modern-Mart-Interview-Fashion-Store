document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');

    // Handle Admin Login
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = loginForm.querySelector('input[type="email"]').value;
            const password = loginForm.querySelector('input[type="password"]').value;

            const users = JSON.parse(localStorage.getItem('users')) || [];
            console.log('Users in localStorage:', users);
            console.log('Entered email:', email);
            console.log('Entered password:', password);

            const user = users.find(u => u.email === email && u.isAdmin);
            console.log('User found:', user); // Log the found user for debugging

            if (user) {
                console.log('Comparing password...');
                if (password === user.password) {
                    console.log('Password match, logging in...');
                    sessionStorage.setItem('adminName', user.username);
                    alert('Redirecting to admin-dashboard.html');
                    window.location.href = 'admin-dashboard.html'; // Redirect to admin dashboard
                } else {
                    alert('Invalid credentials');
                }
            } else {
                alert('User not found or not an admin');
            }
        });
    }
});
