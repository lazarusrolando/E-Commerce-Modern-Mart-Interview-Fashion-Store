document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    // Handle Admin Login
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = loginForm.querySelector('input[type="text"]').value;
            const password = loginForm.querySelector('input[type="password"]').value;

            // Check if user is admin
            const admins = JSON.parse(localStorage.getItem('admins')) || [];
            const admin = admins.find(a => a.username === username);
            
            if (admin) {
                console.log('Admin found, comparing password...');
                // Compare plain password
                if (password === admin.password) {
                    console.log('Password match, logging in...');
                    // Store login state in session storage
                    sessionStorage.setItem('loggedInAdmin', JSON.stringify({
                        username: admin.username,
                        name: admin.name
                    }));
                    sessionStorage.setItem('adminName', admin.name); // Store admin name for display

                    // Redirect to dashboard
                    window.location.href = 'index.html';
                } else {
                    alert('Invalid credentials');
                }
            } else {
                alert('Admin not found');
            }
        });
    }

    // Handle Admin Registration
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const adminUsername = registerForm.querySelector('input[type="text"]').value;
            const email = registerForm.querySelector('input[type="email"]').value;
            const password = registerForm.querySelector('input[type="password"]').value;

            // Create admin object with plain password
            const admin = {
                id: 'admin-' + Date.now().toString(36) + Math.random().toString(36).substr(2),
                username: adminUsername,
                email: email,
                password: password,
                name: adminUsername,
                role: 'admin',
                status: 'active',
                registered: new Date().toISOString(),
                lastLogin: null
            };

            // Store admin in localStorage
            const admins = JSON.parse(localStorage.getItem('admins')) || [];
            
            // Check if username or email already exists
            console.log('Checking for existing admin...');
            const exists = admins.some(a => a.username === username || a.email === email);
            if (exists) {
                console.log('Admin already exists with username/email:', username, email);
                alert('Username or email already exists');
                return;
            }
            
            console.log('Admin does not exist, creating new admin...');
            admins.push(admin);
            localStorage.setItem('admins', JSON.stringify(admins));

            // Update admin statistics
            const totalAdmins = parseInt(localStorage.getItem('totalAdmins') || '0');
            localStorage.setItem('totalAdmins', totalAdmins + 1);

            alert('Admin registration successful! Please login.');
            if (loginForm) {
                loginForm.querySelector('input[type="text"]').value = username;
                loginForm.querySelector('input[type="password"]').value = password;
            }
        });
    }
});

// Check if admin is logged in
function checkAdminLogin() {
    const loggedInAdmin = sessionStorage.getItem('loggedInAdmin');
    if (!loggedInAdmin) {
        window.location.href = '../account.html';
        return null;
    }
    
    // Update last login time
    const adminData = JSON.parse(loggedInAdmin);
    const admins = JSON.parse(localStorage.getItem('admins')) || [];
    const admin = admins.find(a => a.email === adminData.email);
    if (admin) {
        admin.lastLogin = new Date().toISOString();
        localStorage.setItem('admins', JSON.stringify(admins));
    }
    
    return adminData;
}

// Logout functionality
function adminLogout() {
    sessionStorage.removeItem('loggedInAdmin');
    window.location.href = '../account.html';
}
