document.addEventListener('DOMContentLoaded', function() {
    const admins = JSON.parse(localStorage.getItem('admins')) || [];
    const tableBody = document.getElementById('adminsTableBody');

    let totalAdmins = admins.length;
    let activeAdmins = admins.filter(admin => admin.status === 'active').length;
    let loggedInAdmins = admins.filter(admin => {
        const lastLogin = new Date(admin.lastLogin);
        const now = new Date();
        return (now - lastLogin) < (30 * 60 * 1000); // Admins active in last 30 minutes
    }).length;


    document.getElementById('totalAdminsCount').innerText = totalAdmins;
    document.getElementById('activeAdminsCount').innerText = activeAdmins;
    document.getElementById('loggedInAdminsCount').innerText = loggedInAdmins;


    admins.forEach((admin, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${admin.name}</td>
            <td>${admin.email}</td>
            <td>${admin.role}</td>
            <td>${admin.permissions.join(', ')}</td>
            <td>${admin.status}</td>
            <td>
                <button onclick="editAdmin('${admin.email}')">Edit</button>
                <button onclick="deleteAdmin('${admin.email}')">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
});

function editAdmin(email) {
    const admins = JSON.parse(localStorage.getItem('admins')) || [];
    const admin = admins.find(a => a.email === email);
    if (!admin) {
        alert('Admin not found');
        return;
    }
    
    const newPermissions = prompt('Enter new permissions (comma separated):', admin.permissions.join(', '));
    if (newPermissions) {
        admin.permissions = newPermissions.split(',').map(p => p.trim());
        localStorage.setItem('admins', JSON.stringify(admins));
        location.reload();
    }
}


function deleteAdmin(email) {
    if (!confirm('Are you sure you want to delete this admin?')) {
        return;
    }
    
    let admins = JSON.parse(localStorage.getItem('admins')) || [];
    admins = admins.filter(admin => admin.email !== email);
    localStorage.setItem('admins', JSON.stringify(admins));
    
    // Update admin statistics
    const totalAdmins = parseInt(localStorage.getItem('totalAdmins') || '0');
    localStorage.setItem('totalAdmins', totalAdmins - 1);
    
    location.reload();
}
