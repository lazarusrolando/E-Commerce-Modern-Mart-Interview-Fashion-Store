document.addEventListener('DOMContentLoaded', () => {
    const ordersContainer = document.querySelector('.orders-list'); // Select the orders container

    function getStatusText(status) {
        switch (status) {
            case 'pending':
                return 'Pending';
            case 'shipped':
                return 'Shipped';
            case 'delivered':
                return 'Delivered';
            case 'cancelled':
                return 'Cancelled';
            default:
                return 'Unknown Status';
        }
    }

    const username = localStorage.getItem('username') || 'Guest'; // Default to 'Guest' if not logged in
    const loadingIndicator = document.querySelector('.loading-indicator'); // Define loading indicator

    function displayOrders(filteredOrders) {
        loadingIndicator.style.display = 'block'; // Show loading indicator
        if (Array.isArray(filteredOrders) && filteredOrders.length > 0) {
            loadingIndicator.style.display = 'none'; // Hide loading indicator after displaying

            filteredOrders.forEach((order) => { 
                const orderDate = new Date(order.date).toLocaleDateString();
                const orderTotal = (order.total && typeof order.total === 'number') ? order.total.toFixed(2) : '0.00';
                const orderStatusText = getStatusText(order.status) || 'Unknown Status';

                function getStatusIcon(status) {
                    switch (status) {
                        case 'pending':
                            return 'bi-clock'; // Example icon for pending
                        case 'shipped':
                            return 'bi-truck'; // Example icon for shipped
                        case 'delivered':
                            return 'bi-check-circle'; // Example icon for delivered
                        case 'cancelled':
                            return 'bi-x-circle'; // Example icon for cancelled
                        default:
                            return 'bi-question-circle'; // Default icon for unknown status
                    }
                }
                const orderStatusIcon = getStatusIcon(order.status);

                const orderItems = (order.items && Array.isArray(order.items)) ? order.items.map(item => `
                    <div class="item-card">
                        <div class="item-image">
                            <img src="${item.img && item.img.singleImage ? item.img.singleImage : item.image}" alt="${item.name}" />
                        </div>
                        <div class="item-info">
                            <h4 class="item-name">${item.name}</h4>
                            <div class="item-price">₹${(item.price?.newPrice || item.price).toFixed(2)}</div>
                            <div class="item-quantity">Quantity: ${item.quantity}</div>
                            <div class="item-actions">
                                <button class="btn-secondary" onclick="buyAgain(${order.id}, ${item.id})">
                                    Buy it again
                                </button>
                                ${order.status === 'delivered' ? ` 
                                    <button class="btn-secondary" onclick="writeReview(${item.id})">
                                        Write a product review
                                    </button>
                                ` : ''} 
                                ${order.status !== 'delivered' && order.status !== 'cancelled' ? `
                                    <button class="btn-secondary cancel-order-btn" onclick="cancelOrder(${order.id})">
                                        Cancel Order
                                    </button>
                                ` : ''}
                            </div>
                        </div>
                    </div>
                `).join('') : '';

                ordersContainer.innerHTML += `
                <div class="order-item ${order.status}" style="background: linear-gradient(90deg, #4c51bf, #6f7dff);" data-order-id="${order.id}">
                    <div class="order-header">
                        <div class="order-info-grid">
                            <div class="order-placed">
                                <span class="label">ORDER PLACED</span>
                                <span class="value">${orderDate}</span>
                            </div>
                            <div class="order-total">
                                <span class="label">TOTAL</span>
                                <span class="value">₹${orderTotal}</span>
                            </div>
                            <div class="order-ship-to">
                                <div class="ship-to-info">
                                    <span class="label">SHIP TO</span>
                                    <div class="address-details">
                                    <strong>${username}</strong>
                                    </div>
                                </div>
                            </div>
                            <div class="order-number">
                                <span class="label">ORDER # ${order.id}</span>
                                <div class="order-actions">
                                    <button class="btn-link" onclick="generateInvoice(${order.id})">
                                        Invoice
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="delivery-status">
                            <div class="status-icon ${order.status}">
                                <i class="bi ${orderStatusIcon}"></i>
                            </div>
                            <div class="status-text">
                                <h4>${orderStatusText}</h4>
                                <p>${getStatusMessage(order.status, order.estimatedDelivery)}</p>
                            </div>
                        </div>
                    </div>
                    <div class="order-content">
                        <div class="items-grid">
                            ${orderItems}
                        </div>
                    </div>
                </div>
            `;
            });
            return; // Exit the function if no orders
        }        
        loadingIndicator.style.display = 'none'; // Hide loading indicator after displaying
    }

    // Fetch and display cart items
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || []; // Fetch product details
    console.log('Retrieved cart items:', cartItems); // Debugging line
    if (cartItems.length > 0) {
        displayOrders(cartItems); // Display the product details after fetching
    } else {
        console.log('No cart items found to display.'); // Debugging line
    }
});
