// User Dropdown Management
document.addEventListener('DOMContentLoaded', function() {
    // Wait a bit for Bootstrap Icons to load
    setTimeout(() => {
        initializeUserDropdown();
        
        // If no user is logged in, ensure admin button is visible
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        if (!isLoggedIn) {
            showAdminButton();
        }
    }, 100);
});

function getCorrectPath(filename) {
    // Check if we're in a subdirectory by looking at the current path
    const currentPath = window.location.pathname;
    const isInSubdirectory = currentPath.includes('/categories/') || currentPath.includes('/products/');
    
    if (isInSubdirectory) {
        // Count directory levels to determine how many ../ we need
        const pathParts = currentPath.split('/');
        const depth = pathParts.length - 2; // -1 for filename, -1 for root
        const prefix = '../'.repeat(Math.max(0, depth - 1));
        return prefix + filename;
    }
    
    return filename;
}

function checkBootstrapIcons() {
    // Check if Bootstrap Icons font is loaded
    const testElement = document.createElement('i');
    testElement.className = 'bi bi-person-circle';
    testElement.style.position = 'absolute';
    testElement.style.left = '-9999px';
    document.body.appendChild(testElement);
    
    const computedStyle = window.getComputedStyle(testElement);
    const fontFamily = computedStyle.fontFamily;
    
    document.body.removeChild(testElement);
    
    return fontFamily.includes('bootstrap-icons');
}

function initializeUserDropdown() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const username = localStorage.getItem('username');
    
    // Find all user account links
    const userLinks = document.querySelectorAll('a[href*="user-account.html"]');
    
    userLinks.forEach(userLink => {
        if (isLoggedIn && username) {
            // Replace the user link with dropdown
            createUserDropdown(userLink, username);
            
            // Check if user is admin
            const isAdmin = checkIfUserIsAdmin(username);
            
            // Hide admin button for regular users, keep it for admins
            if (!isAdmin) {
                hideAdminButton();
            }
        }
    });
}

function checkIfUserIsAdmin(username) {
    // Check if the user is an admin based on username or stored user data
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const currentUser = users.find(user => user.username === username || user.email === username);
    
    // Return true if user is admin, false otherwise
    return currentUser && currentUser.isAdmin === true;
}

function hideAdminButton() {
    // Find and hide admin links when user is logged in
    const adminLinks = document.querySelectorAll('a[href*="account.html"]');
    adminLinks.forEach(adminLink => {
        // Check if this is the admin button in the header navigation
        const linkText = adminLink.textContent.trim();
        const hasAdminText = linkText.includes('Admin');
        const hasPersonIcon = adminLink.querySelector('i.bi-person');
        
        if (hasAdminText && hasPersonIcon) {
            adminLink.style.display = 'none';
        }
    });
}

function createUserDropdown(userLink, username) {
    // Create dropdown container
    const dropdownContainer = document.createElement('div');
    dropdownContainer.className = 'user-dropdown-container';
    
    // Create dropdown trigger
    const dropdownTrigger = document.createElement('button');
    dropdownTrigger.className = 'user-dropdown-trigger';
    
    // Use simple text-based design for better compatibility
    dropdownTrigger.innerHTML = `
        <span class="user-icon">👤</span>
        <span class="username">${username}</span>
        <span class="dropdown-arrow">▼</span>
    `;
    
    // Create dropdown menu
    const dropdownMenu = document.createElement('div');
    dropdownMenu.className = 'user-dropdown-menu';
    dropdownMenu.innerHTML = `
        <a href="${getCorrectPath('user-dashboard.html')}" class="dropdown-item">
            <span class="menu-icon">📊</span>
            <span>Dashboard</span>
        </a>
        <a href="${getCorrectPath('user-profile.html')}" class="dropdown-item">
            <span class="menu-icon">👤</span>
            <span>Profile</span>
        </a>
        <a href="${getCorrectPath('settings.html')}" class="dropdown-item">
            <span class="menu-icon">⚙️</span>
            <span>Settings</span>
        </a>
        <a href="${getCorrectPath('wishlist.html')}" class="dropdown-item">
            <span class="menu-icon">❤️</span>
            <span>Wishlist</span>
        </a>
        <div class="dropdown-divider"></div>
        <a href="#" class="dropdown-item logout-item" onclick="logoutUser()">
            <span class="menu-icon">🚪</span>
            <span>Logout</span>
        </a>
    `;
    
    // Add click event to toggle dropdown
    dropdownTrigger.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        // Close other dropdowns
        document.querySelectorAll('.user-dropdown-menu').forEach(menu => {
            if (menu !== dropdownMenu) {
                menu.style.display = 'none';
            }
        });
        
        // Toggle current dropdown
        dropdownMenu.style.display = dropdownMenu.style.display === 'block' ? 'none' : 'block';
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        if (!dropdownContainer.contains(e.target)) {
            dropdownMenu.style.display = 'none';
        }
    });
    
    // Assemble dropdown
    dropdownContainer.appendChild(dropdownTrigger);
    dropdownContainer.appendChild(dropdownMenu);
    
    // Replace the original user link
    userLink.parentNode.replaceChild(dropdownContainer, userLink);
}

function showAdminButton() {
    // Show admin links when user logs out
    const adminLinks = document.querySelectorAll('a[href*="account.html"]');
    adminLinks.forEach(adminLink => {
        const linkText = adminLink.textContent.trim();
        const hasAdminText = linkText.includes('Admin');
        const hasPersonIcon = adminLink.querySelector('i.bi-person');
        
        if (hasAdminText && hasPersonIcon) {
            adminLink.style.display = '';
        }
    });
}

function logoutUser() {
    if (confirm('Are you sure you want to logout?')) {
        // Clear all login data
        localStorage.removeItem('isLoggedIn');
        localStorage.removeItem('username');
        localStorage.removeItem('profileUsername');
        localStorage.removeItem('userEmail');
        localStorage.removeItem('userPhone');
        sessionStorage.clear();
        
        // Show admin button again
        showAdminButton();
        
        // Redirect to login page
        window.location.href = 'user-account.html';
    }
}