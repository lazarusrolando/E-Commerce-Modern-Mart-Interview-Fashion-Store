function openAnalyticsModal() {
    const modalContent = `
        <div class="modal-content">
            <section class="dashboard-content" style="display: flex; flex-direction: row; align-items: center; justify-content: space-around; text-align: center; margin: 0 auto; width: 100%; border-radius: 10px;">
                <span class="close" onclick="closeAnalyticsModal()">&times;</span>
                <div class="card">
                    <i class="bi bi-person-fill" style="font-size: 50px; color: #4c51bf;"></i>
                    <h3>Total Users</h3>
                    <p id="totalUsers">0</p>
                </div>
                <div class="card">
                    <i class="bi bi-person-check-fill" style="font-size: 50px; color: #28a745;"></i>
                    <h3>Active Users</h3>
                    <p id="activeUsers">0</p>
                </div>
                <div class="card">
                    <i class="bi bi-person-x-fill" style="font-size: 50px; color: #ed190a;"></i>
                    <h3>Inactive Users</h3>
                    <p id="inactiveUsers">0</p>
                </div>
            </section>
        </div>
    `;
    document.getElementById('analyticsModal').innerHTML = modalContent; // Populate modal content
    document.getElementById('analyticsModal').style.display = 'block'; // Show the modal

    // Fetch user statistics immediately
    fetchUserStatistics();
}

function closeAnalyticsModal() {
    document.getElementById('analyticsModal').style.display = 'none'; // Hide the modal
}

function fetchUserStatistics() {
    // Retrieve the users from local storage
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const totalUsers = users.length; // Count the number of users
    const activeUsers = totalUsers; // Assuming all logged-in users are active
    const inactiveUsers = 0; // Assuming no inactive users for simplicity

    // Update the modal content with the fetched data
    document.getElementById('totalUsers').textContent = totalUsers;
    document.getElementById('activeUsers').textContent = activeUsers;
    document.getElementById('inactiveUsers').textContent = inactiveUsers;
}
