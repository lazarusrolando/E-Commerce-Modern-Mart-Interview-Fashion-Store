// Initialize wishlist and wishlist counts
let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];
const wishlistCount = document.querySelector('.header-wishlist-count');
const wishlistPageCount = document.querySelector('.wishlist-count');

// Update wishlist counts and total value
function updateWishlistCount() {
    const count = wishlist.length;
    const totalValue = wishlist.reduce((sum, item) => sum + parseFloat(item.price), 0);
    
    wishlistCount.textContent = count;
    wishlistCount.style.display = count > 0 ;
    
    if (wishlistPageCount) {
        wishlistPageCount.textContent = count;
    }
    
    const totalValueElement = document.querySelector('.wishlist-total-value');
    if (totalValueElement) {
        totalValueElement.textContent = totalValue.toFixed(2);
    }
}

// Add item to wishlist
export function addToWishlist(product) {
    const existingItem = wishlist.find(item => item.id === product.id);
    if (!existingItem) {
        wishlist.push(product);
        localStorage.setItem('wishlist', JSON.stringify(wishlist));
        updateWishlistCount();
        displayWishlist();
        return true;
    }
    return false;
}

// Handle wishlist button clicks
document.addEventListener('click', (e) => {
    if (e.target.closest('.wishlist-btn')) {
        const productId = e.target.closest('.wishlist-btn').dataset.id;
        const productName = e.target.closest('.wishlist-btn').dataset.name;
        const productPrice = e.target.closest('.wishlist-btn').dataset.price;
        
        const product = {
            id: productId,
            name: productName,
            price: parseFloat(productPrice)
        };
        
        if (addToWishlist(product)) {
            showToast('Added to wishlist!', 'success');
        } else {
            showToast('Already in wishlist!', 'info');
        }
    }
});

// Display wishlist items
function displayWishlist() {
    const wishlistContainer = document.querySelector('.wishlist-items');
    updateWishlistCount();

    wishlistContainer.innerHTML = '';

    if (wishlist.length === 0) {
        wishlistContainer.innerHTML = `
            <div class="empty-wishlist-container">
                <div class="empty-wishlist">
                    <i><p>Your wishlist is empty.</p></i>           
                </div>
            </div>`;
        return;
    }

    wishlist.forEach(item => {
        const wishlistItem = document.createElement('div');
        wishlistItem.className = 'wishlist-item';
        wishlistItem.innerHTML = `
            <div class="wishlist-item-content">
                <h3 class="wishlist-item-title">${item.name}</h3>
                <p class="wishlist-price">&#x20B9;${item.price.toFixed(2)}</p>
                <div class="wishlist-actions">
                    <button class="btn btn-danger remove-btn" data-id="${item.id}">
                        <i class="bi bi-trash"></i> Remove
                    </button>
                </div>
            </div>
        `;
        wishlistContainer.appendChild(wishlistItem);
    });

    // Add event listeners for remove buttons
    document.querySelectorAll('.remove-btn').forEach(button => {
        button.addEventListener('click', (e) => {
            const productId = e.target.dataset.id;
            wishlist = wishlist.filter(item => item.id !== productId);
            localStorage.setItem('wishlist', JSON.stringify(wishlist));
            displayWishlist();
            updateWishlistCount();
            showToast('Product removed from wishlist', 'success');
        });
    });
}

// Initialize wishlist display when page loads
document.addEventListener('DOMContentLoaded', () => {
    if (document.querySelector('.wishlist-container')) {
        displayWishlist();
        updateWishlistCount();
        
        // Add event listener for clear wishlist button
        const clearWishlistBtn = document.getElementById('clear-wishlist');
        if (clearWishlistBtn) {
            clearWishlistBtn.addEventListener('click', () => {
                wishlist = [];
                localStorage.setItem('wishlist', JSON.stringify(wishlist));
                displayWishlist();
                updateWishlistCount();
                showToast('Wishlist cleared successfully', 'success');
            });
        }
    }
});


// Show toast notifications
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}
