function loadUsers() {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userTableBody = document.getElementById('userTableBody');
    
    // Check if userTableBody exists
    if (userTableBody) {
        userTableBody.innerHTML = '';

        users.forEach(user => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.id}</td>
                <td>${user.username}</td>
                <td>${user.email}</td>
                <td>${user.password}</td>
                <td>${user.status}</td>
                <td>${user.role}</td>
                <td>
                    <button class="editUser" onclick="editUser(${user.id})">Edit</button>
                    <button class="deleteUser" onclick="deleteUser(${user.id})">Delete</button>
                </td>
            `;
            userTableBody.appendChild(row);
        });
    } else {
        console.error('userTableBody element not found!');
    }
}

function editUser(userId) {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const user = users.find(u => u.id === userId);

    if (user) {
        document.getElementById('newUsername').value = user.username;
        document.getElementById('newEmail').value = user.email;

        // Change the button action to update the user
        const saveButton = document.querySelector('.modal-content button');
        saveButton.onclick = function() {
            user.username = document.getElementById('newUsername').value;
            user.email = document.getElementById('newEmail').value;

            // Update the users array in local storage
            localStorage.setItem('users', JSON.stringify(users));
            alert('User updated successfully!');
            loadUsers(); // Refresh the user list
            closeAddUserModal(); // Close the modal
        };

        openAddUserModal(); // Open the modal
    }
}

document.addEventListener('DOMContentLoaded', function () {
    // Add toggle password visibility functionality
    const togglePassword = document.getElementById('togglePassword');
    if (togglePassword) {
        togglePassword.addEventListener('click', function () {
            const passwordInput = document.getElementById('newPassword');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.textContent = type === 'password' ? '👁️' : '🙈'; // Change icon based on visibility
        });
    }

    loadUsers(); // Load users into the table after DOM is fully loaded
    console.log('Users loaded successfully'); // Log success message

    const users = JSON.parse(localStorage.getItem('users')) || [];

    let currentUser = JSON.parse(sessionStorage.getItem('currentUser')) ||
        getCookie('currentUser');

    const cartIcon = document.querySelector('.cart-icon');
    const header = document.querySelector('header');

    // Update username display
    function updateUsernameDisplay(username) {
        const existingDisplay = document.querySelector('.username-display');
        if (existingDisplay) {
            existingDisplay.remove();
        }

        if (username && cartIcon) {
            const usernameDisplay = document.createElement('span');
            usernameDisplay.className = 'username-display';
            usernameDisplay.textContent = username;
            usernameDisplay.style.marginLeft = '10px';
            usernameDisplay.style.fontWeight = 'bold';
            usernameDisplay.style.color = '#333';
            usernameDisplay.style.fontSize = '1.1em';
            usernameDisplay.style.position = 'relative';
            usernameDisplay.style.top = '-2px';
            cartIcon.insertAdjacentElement('afterend', usernameDisplay);
        }
    }

    // Handle User Addition
    function addUser() {
        const username = document.getElementById('newUsername').value;
        const email = document.getElementById('newEmail').value;

        // Check if user already exists
        if (users.some(u => u.username === username || u.email === email)) {
            alert('Username or email already exists');
            return;
        }

        // Initialize user counter if not exists
        let userCounter = parseInt(localStorage.getItem('userCounter') || '0');
        userCounter++;
        localStorage.setItem('userCounter', userCounter.toString());

        // Create new user with sequential ID
        const newUser = {
            id: userCounter,
            username,
            email,
            status: 'active',
            createdAt: new Date().toISOString(),
        };

        users.push(newUser);
        localStorage.setItem('users', JSON.stringify(users));
        
        alert('User added successfully!');
        loadUsers(); // Refresh the user list
    }

    const registerForm = document.getElementById('userRegisterForm'); // Get the registration form

    if (registerForm) {
        registerForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const username = registerForm.querySelector('input[type="text"]').value;
            const email = registerForm.querySelector('input[type="email"]').value;
            const password = registerForm.querySelector('input[type="password"]').value;

            // Check if user already exists
            if (users.some(u => u.username === username || u.email === email)) {
                alert('Username or email already exists');
                return;
            }

            // Initialize user counter if not exists
            let userCounter = parseInt(localStorage.getItem('userCounter') || '0');
            userCounter++;
            localStorage.setItem('userCounter', userCounter.toString());

            // Create new user with sequential ID
            const newUser = {
                id: userCounter,
                username,
                email,
                password, // Note: In production, hash the password
                role: 'customer',
                status: 'active',
                createdAt: new Date().toISOString(),
                lastLogin: null
            };

            users.push(newUser);
            localStorage.setItem('users', JSON.stringify(users));
            
            // Store registration activity for admin dashboard
            const activity = {
                type: 'user_registration',
                userId: newUser.id,
                username: username,
                email: email,
                timestamp: new Date().toISOString()
            };

            const activities = JSON.parse(localStorage.getItem('adminActivities') || '[]');
            activities.push(activity);
            localStorage.setItem('adminActivities', JSON.stringify(activities));
            
            // Update user statistics
            const totalUsers = parseInt(localStorage.getItem('totalUsers') || '0');
            const activeUsers = parseInt(localStorage.getItem('activeUsers') || '0');
            localStorage.setItem('totalUsers', totalUsers + 1);
            localStorage.setItem('activeUsers', activeUsers + 1);
            localStorage.setItem('lastRegisteredUser', JSON.stringify(newUser));

            alert('Account registered successfully! You can now login.');
            registerForm.reset();
        });
    }

    // Handle User Deletion
    function deleteUser(userId) {
        const users = JSON.parse(localStorage.getItem('users')) || [];
        const updatedUsers = users.filter(user => user.id !== userId);
        localStorage.setItem('users', JSON.stringify(updatedUsers));
        
        alert('User deleted successfully!');
        loadUsers(); // Refresh the user list
    }

    const loginForm = document.getElementById('userLoginForm'); // Get the login form

    if (loginForm) {
        loginForm.addEventListener('submit', function (e) {
            e.preventDefault();

            const username = loginForm.querySelector('input[type="text"]').value;
            const password = loginForm.querySelector('input[type="password"]').value;

            const user = users.find(u =>
                (u.username === username || u.email === username) &&
                u.password === password
            );

            if (user) {
                sessionStorage.setItem('currentUser', JSON.stringify(user));
                updateUsernameDisplay(user.username);
                alert('Login successful!');
                window.location.href = 'index.html';
            } else {
                alert('Invalid username/email or password');
            }
        });
    }

    // Handle Logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function () {
            sessionStorage.removeItem('currentUser');
            document.cookie = 'currentUser=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
            updateUsernameDisplay(null);
            window.location.href = 'index.html';
        });
    }

    // Initialize username display if logged in
    if (currentUser) {
        updateUsernameDisplay(currentUser.username);
    }

    // Helper function to get cookie value
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return parts.pop().split(';').shift();
    }
}); // End of DOMContentLoaded event
