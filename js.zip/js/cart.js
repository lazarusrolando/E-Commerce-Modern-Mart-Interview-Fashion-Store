document.addEventListener('DOMContentLoaded', () => {
    let cart = localStorage.getItem("cart") ? JSON.parse(localStorage.getItem("cart")) : [];
    const shippingCost = 50; // Set a fixed shipping cost
    const shippingThreshold = 500; // Minimum amount for free shipping

    function dispatchCartUpdatedEvent() {
        const event = new Event('cartUpdated');
        window.dispatchEvent(event);
    }

    // Listen for cart updates
    window.addEventListener('cartUpdated', () => {
        displayCartProduct();
        saveCartValues();
    });

    function proceedToCheckout() {
        const productDetails = cart.map(item => ({
            id: item.id,
            name: item.name,
            price: item.price.newPrice,
            quantity: item.quantity
        }));
        localStorage.setItem("productDetails", JSON.stringify(productDetails));
        window.location.href = "user-dashboard.html";
    }

    function displayCartProduct() {
        console.log("Displaying cart products:", cart); // Debugging line to check cart contents
        let results = "";
        const cartItemsDiv = document.getElementById("cart-product"); // Reference to the correct ID
        cart.forEach((item) => {
            if (item.quantity < 1) {
                item.quantity = 1;
            }
            results += `
            <tr class="cart-item">
                <td></td>
                <td class="cart-image">
                    <img src="${item.img.singleImage}" alt="" data-id=${item.id} class="cart-product-image">
                    <i class="bi bi-x delete-cart" style='font-size:15px border-radius: 5px'; data-id=${item.id}></i>
                </td>
                <td>${item.name}</td>
                <td>&#x20B9;${item.price.newPrice.toFixed(2)}</td>
                <td>
                    <input type="number" min="1" value="${item.quantity}" 
                           class="quantity-input" data-id="${item.id}">
                </td>
                <td>&#x20B9;${(item.price.newPrice * item.quantity).toFixed(2)}</td>
            </tr>
            `;
        });
        if (cartItemsDiv) {
            cartItemsDiv.innerHTML = results; // Update the new ID with cart items
        } else {
            console.error("Element with ID 'cart-product' not found.");
        }
        
        setupQuantityInputs();
        removeCartItem();
        cartProductRoute();
    }

    // Make displayCartProduct available globally
    window.displayCartProduct = displayCartProduct;

    function setupQuantityInputs() {
        document.querySelectorAll('.quantity-input').forEach(input => {
            input.addEventListener('change', (e) => {
                const id = Number(e.target.dataset.id);
                const newQuantity = Number(e.target.value);
                const cartItem = cart.find(item => item.id === id);
                if (cartItem && newQuantity >= 1) {
                    cartItem.quantity = newQuantity;
                    localStorage.setItem("cart", JSON.stringify(cart));
                    dispatchCartUpdatedEvent();
                }
            });
        });
    }

    function cartProductRoute() {
        document.querySelectorAll(".cart-product-image").forEach(image => {
            image.addEventListener("click", (e) => {
                localStorage.setItem("productId", Number(e.target.dataset.id));
                window.location.href = "single-product.html";
            });
        });
    }

    function removeCartItem() {
        document.querySelectorAll(".delete-cart").forEach(button => {
            button.addEventListener("click", (e) => {
                const id = Number(e.target.dataset.id);
                cart = cart.filter(item => item.id !== id);
                localStorage.setItem("cart", JSON.stringify(cart));
                dispatchCartUpdatedEvent();
            });
        });
    }

    function saveCartValues() {
        const cartTotal = document.getElementById("cart-total");
        const subTotal = document.getElementById("subtotal");
        const fastCargo = document.getElementById("fast-cargo");
        let itemsTotal = cart.reduce((sum, item) => sum + item.price.newPrice * item.quantity, 0);
        
        subTotal.innerHTML = `&#x20B9;${itemsTotal.toFixed(2)}`;
        const shippingAmount = fastCargo.checked ? shippingCost : 0; // Calculate shipping amount
        cartTotal.innerHTML = `&#x20B9;${(itemsTotal + shippingAmount).toFixed(2)}`; // Update cart total

        // Display shipping amount
        const shippingDisplay = document.getElementById("shipping-amount"); // Get shipping display element
        if (shippingDisplay) {
            shippingDisplay.innerHTML = `&#x20B9;${shippingAmount.toFixed(2)}`; // Update shipping amount display
        }

        fastCargo.addEventListener("change", () => {
            const shippingAmount = fastCargo.checked ? shippingCost : 0; // Calculate shipping amount
            cartTotal.innerHTML = `&#x20B9;${(itemsTotal + shippingAmount).toFixed(2)}`; // Update cart total
            const shippingDisplay = document.getElementById("shipping-amount"); // Get shipping display element
            if (shippingDisplay) {
                shippingDisplay.innerHTML = `&#x20B9;${shippingAmount.toFixed(2)}`; // Update shipping amount display
            }
        });

        document.querySelector(".header-cart-count").innerText = cart.length;
    }

    // Initial load
    displayCartProduct();
    saveCartValues();
});
