import { product1, product2 } from "./glide.js"
import { addToWishlist } from "./wishlist.js"

export let cart = localStorage.getItem("cart")
    ? JSON.parse(localStorage.getItem("cart")) : []


function addToCart(products) {
    const cartItem = document.querySelector(".header-cart-count");
    const buttons = [...document.getElementsByClassName("add-to-cart")];
    
    const updateCartUI = () => {
        cartItem.innerHTML = cart.length;
        if (window.location.pathname.includes('cart.html')) {
            window.dispatchEvent(new Event('cartUpdated'));
        }
    };

    buttons.forEach((button) => {
        const inCart = cart.find((item) => item.id === Number(button.dataset.id));
        if (inCart) {
            inCart.quantity += 1;
            localStorage.setItem("cart", JSON.stringify(cart));
            button.setAttribute("enabled", "enabled");
            updateCartUI();
        } else {
            button.addEventListener("click", function (e) {
                const id = e.target.dataset.id;
                const findProduct = products.find((product) => product.id === Number(id));
                cart.push({ ...findProduct, quantity: 1 });
                localStorage.setItem("cart", JSON.stringify(cart));
                button.setAttribute("enabled", "enabled");
                updateCartUI();
                
                // Show visual feedback
                button.classList.add('added-to-cart');
                setTimeout(() => {
                    button.classList.remove('added-to-cart');
                }, 1000);
            });
        }
    });
}

function productRoute() {
    const productLink = document.getElementsByClassName("product-link")
    Array.from(productLink).forEach((button) => {
        button.addEventListener("click", (e) => {
            e.preventDefault()
            const id = e.target.dataset.id
            localStorage.setItem("productId", JSON.stringify(id))
            window.location.href = "single-product.html"
        })
    })
}


function productImageRoute() {
    const productImageLink = document.querySelectorAll(".product-image a .img2")
    productImageLink.forEach((item) => {
        item.addEventListener("click", (e) => {
            e.preventDefault()
            const id = e.target.dataset.id
            localStorage.setItem("productId", JSON.stringify(id))
            window.location.href = `../products/product${id}.html`
        })
    })
}

async function productFunc(products) {


    const productsContainer = document.getElementById("product-list")
    const productsContainer2 = document.getElementById("product-list-2")
    let results = ""

    products.forEach((product) => {
        results += `
                <li class="product-item glide__slide">
                    <div class="product-image">
                        <a href="" >
                            <img src="${product.img.singleImage}" alt="" class="img1" />
                            <img src="${product.img.thumbs[1]}" alt="" class="img2" data-id="${product.id}" />
                        </a>
                    </div>
                    <div class="product-info">
                    <a href="#" class="product-title"> ${product.name} </a>
                    <ul class="product-star">
                        <li>
                        <i class="bi bi-star-fill"></i>
                        </li>
                        <li>
                        <i class="bi bi-star-fill"></i>
                        </li>
                        <li>
                        <i class="bi bi-star-fill"></i>
                        </li>
                        <li>
                        <i class="bi bi-star-fill"></i>
                        </li>
                        <li>
                        <i class="bi bi-star-half"></i>
                        </li>
                    </ul>
                    <div class="product-prices">
                        <strong class="new-price">&#x20B9;${product.price.newPrice.toFixed(2)}</strong>
                        <span class="old-price">&#x20B9;${product.price.oldPrice.toFixed(2)}</span>
                    </div>
                    <span class="product-discount">${product.discount}% </span>
                    <div class="product-links">
                  <button class="add-to-cart" data-id="${product.id}">
                    <i class="bi bi-basket-fill"></i>
                  </button>
                  <button class="wishlist-btn" 
                          data-id="${product.id}"
                          data-name="${product.name}"
                          data-price="${product.price.newPrice}"
                          data-image="${product.img.singleImage}">
                    <i class="bi bi-heart-fill"></i>
                  </button>
                </div>
                    </div>
            </li>
        `

    })

    productsContainer ? productsContainer.innerHTML = results : ""
    productsContainer ? productsContainer2.innerHTML = results : ""

    addToCart(products)

    product1()

    product2()

    productRoute()

    productImageRoute()
    
    // Add wishlist button event listeners
    const wishlistButtons = document.querySelectorAll('.wishlist-btn');
    wishlistButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const product = {
                id: e.currentTarget.dataset.id,
                name: e.currentTarget.dataset.name,
                price: parseFloat(e.currentTarget.dataset.price),
                image: e.currentTarget.dataset.image
            };
            
            addToWishlist(product);
        });
    });
}




export default productFunc
