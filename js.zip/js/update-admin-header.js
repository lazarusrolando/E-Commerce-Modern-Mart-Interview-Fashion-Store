import { updateHeaderForAdmin } from './main.js';

document.addEventListener('DOMContentLoaded', function () {
    const adminName = sessionStorage.getItem('adminName');
    const userLinks = document.querySelector('.header-right-links');

    if (adminName) {
        userLinks.innerHTML = `
            <div class="user-welcome">
                <span>Welcome, ${adminName}</span>
                <div class="user-menu">
                    <a href="admin-dashboard.html">My Dashboard</a>
                    <a href="#" id="logout-btn">Logout</a>
                </div>
            </div>
            <button class="search-button">
                <i class="bi bi-search"></i>
            </button>
            <div class="header-wishlist">
                <a href="wishlist.html" class="header-wishlist-link">
                    <i class="bi bi-heart"></i>
                    <span class="header-wishlist-count">0</span>
                </a>
            </div>
            <div class="header-cart">
                <a href="cart.html" class="header-cart-link">
                    <i class="bi bi-bag"></i>
                    <span class="header-cart-count">0</span>
                </a>
            </div>
        `;

        // Add logout handler
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                sessionStorage.removeItem('adminName'); // Clear admin name on logout
                window.location.href = 'index.html'; // Redirect to login page
            });
        }
    }
});

// Call the function to update the header
updateHeaderForAdmin();
