// User Authentication Module
import bcrypt from 'bcryptjs';

document.addEventListener('DOMContentLoaded', function() {
  // Load users from user-login.json
  let currentUser = checkUserLogin();
  
  // Update UI based on login state
  function updateLoginState(user) {
    const logoutBtn = document.getElementById('logoutBtn');
    const usernameDisplay = document.getElementById('loggedInUsername');
    
    if (user) {
      if (logoutBtn) logoutBtn.style.display = 'inline-block';
      if (usernameDisplay) {
        usernameDisplay.textContent = user.username;
        usernameDisplay.style.display = 'inline';
      }
    } else {
      if (logoutBtn) logoutBtn.style.display = 'none';
      if (usernameDisplay) usernameDisplay.style.display = 'none';
    }
  }
  
  // Initialize UI state
  updateLoginState(currentUser);

  const SALT_ROUNDS = 10;
  const REMEMBER_ME_EXPIRE_DAYS = 60;
  const SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutes

  const usernameDisplay = document.getElementById('loggedInUsername');
  const cartIcon = document.querySelector('.cart-icon');

  // Session Timeout Check
  const lastActivity = localStorage.getItem('lastActivity');
  if (lastActivity && Date.now() - lastActivity > SESSION_TIMEOUT) {
    localStorage.removeItem('currentUser');
    document.cookie = 'currentUser=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    currentUser = null;
  }

  if (currentUser) {
    // Create username element next to cart icon
    const usernameElement = document.createElement('span');
    usernameElement.className = 'username-display';
    usernameElement.textContent = currentUser.username;
    usernameElement.style.marginLeft = '10px';
    usernameElement.style.fontWeight = 'bold';
    
    // Insert username after cart icon
    if (cartIcon) {
      cartIcon.insertAdjacentElement('afterend', usernameElement);
    }
    
    // Also update the existing username display if it exists
    if (usernameDisplay) {
      usernameDisplay.textContent = currentUser.username;
      usernameDisplay.style.display = 'inline';
    }
  } else {
    // Remove username display if logged out
    const existingDisplay = document.querySelector('.username-display');
    if (existingDisplay) {
      existingDisplay.remove();
    }
    
    // Also hide the existing username display if it exists
    if (usernameDisplay) {
      usernameDisplay.style.display = 'none';
    }
  }

  // Session timeout notification
  let timeoutWarning;
  
  // Update last activity on user interaction
  document.addEventListener('click', () => {
    if (currentUser) {
      localStorage.setItem('lastActivity', Date.now());
      if (timeoutWarning) {
        clearTimeout(timeoutWarning);
        timeoutWarning = null;
      }
      
      // Set timeout warning 1 minute before actual session timeout
      timeoutWarning = setTimeout(() => {
        if (confirm('Your session is about to expire. Do you want to stay logged in?')) {
          localStorage.setItem('lastActivity', Date.now());
        } else {
          sessionStorage.removeItem('currentUser');
          document.cookie = 'currentUser=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
          window.location.reload();
        }
      }, SESSION_TIMEOUT - 60000); // 1 minute before timeout
    }
  });

  // Handle User Login
  const loginForm = document.getElementById('userLoginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      // Get form elements
      const usernameInput = loginForm.querySelector('input[type="text"]');
      const passwordInput = loginForm.querySelector('input[type="password"]');
      const rememberMe = loginForm.querySelector('input[type="checkbox"]').checked;
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const spinner = submitBtn.querySelector('.spinner-border');
      const btnText = submitBtn.querySelector('.btn-text');
      
      // Clear previous errors
      document.getElementById('loginUsernameError').textContent = '';
      document.getElementById('loginPasswordError').textContent = '';
      
      // Show loading state
      btnText.style.display = 'none';
      spinner.style.display = 'inline-block';
      
      const username = usernameInput.value;
      const password = passwordInput.value;

      const user = users.find(u => 
        (u.username === username || u.email === username)
      );
      
      if (!user || !(await bcrypt.compare(password, user.password))) {
        document.getElementById('loginUsernameError').textContent = 'Invalid username/email or password';
        document.getElementById('loginPasswordError').textContent = 'Invalid username/email or password';
        btnText.style.display = 'inline-block';
        spinner.style.display = 'none';
        return;
      }

      // Store login state
      if (rememberMe) {
        const date = new Date();
        date.setTime(date.getTime() + (REMEMBER_ME_EXPIRE_DAYS * 24 * 60 * 60 * 1000));
        document.cookie = `currentUser=${JSON.stringify(user)}; expires=${date.toUTCString}; path=/`;
      } else {
        sessionStorage.setItem('currentUser', JSON.stringify(user));
      }

      updateLoginState(user);
      window.location.href = 'index.html';
    });
  }

  // Handle User Registration
  const registerForm = document.getElementById('userRegisterForm');
  if (registerForm) {
    registerForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      // Get form elements
      const usernameInput = registerForm.querySelector('input[type="text"]');
      const emailInput = registerForm.querySelector('input[type="email"]');
      const passwordInput = registerForm.querySelector('input[type="password"]');
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const spinner = submitBtn.querySelector('.spinner-border');
      const btnText = submitBtn.querySelector('.btn-text');
      
      // Clear previous errors
      document.getElementById('registerUsernameError').textContent = '';
      document.getElementById('registerEmailError').textContent = '';
      document.getElementById('registerPasswordError'). textContent = '';
      
      // Show loading state
      btnText.style.display = 'none';
      spinner.style.display = 'inline-block';
      
      const username = usernameInput.value;
      const email = emailInput.value;
      const password = passwordInput.value;

      if (users.some(u => u.username === username)) {
        document.getElementById('registerUsernameError').textContent = 'Username already exists';
        btnText.style.display = 'inline-block';
        spinner.style.display = 'none';
        return;
      }

      if (users.some(u => u.email === email)) {
        document.getElementById('registerEmailError').textContent = 'Email already registered';
        btnText.style.display = 'inline-block';
        spinner.style.display = 'none';
        return;
      }

      // Validate password strength
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
      if (!passwordRegex.test(password)) {
        document.getElementById('registerPasswordError').textContent = 'Password must be at least 8 characters with uppercase, lowercase and numbers';
        btnText.style.display = 'inline-block';
        spinner.style.display = 'none';
        return;
      }

      const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
      const newUser = {
        username,
        email,
        password: hashedPassword,
        createdAt: new Date().toISOString()
      };

      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      btnText.style.display = 'inline-block';
      spinner.style.display = 'none';
      alert('Registration successful! Welcome ' + username + '! Please login.');
      document.getElementById('userLoginForm').querySelector('input[type="text"]').value = username;
      document.getElementById('userLoginForm').querySelector('input[type="password"]').value = password;
    });
  }

  // Handle Password Recovery
  const recoveryForm = document.getElementById('passwordRecoveryForm');
  if (recoveryForm) {
    recoveryForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      // Get form elements
      const emailInput = recoveryForm.querySelector('input[type="email"]');
      const submitBtn = recoveryForm.querySelector('button[type="submit"]');
      const spinner = submitBtn.querySelector('.spinner-border');
      const btnText = submitBtn.querySelector('.btn-text');
      const errorMessage = document.getElementById('recoveryEmailError');
      
      // Clear previous errors
      errorMessage.textContent = '';
      
      // Show loading state
      btnText.style.display = 'none';
      spinner.style.display = 'inline-block';
      
      const email = emailInput.value;
      const user = users.find(u => u.email === email);
      
      if (!user) {
        errorMessage.textContent = 'If an account exists with this email, a recovery link will be sent';
        btnText.style.display = 'inline-block';
        spinner.style.display = 'none';
        return;
      }
      
      // Simulate sending recovery email
      setTimeout(() => {
        btnText.style.display = 'inline-block';
        spinner.style.display = 'none';
        alert('Password recovery instructions sent to your email');
        window.location.hash = '#login';
      }, 1500);
    });
  }

  // Handle User Logout
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function() {
      sessionStorage.removeItem('currentUser');
      document.cookie = 'currentUser=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
      window.location.href = 'index.html';
    });
  }

  // Check if user is logged in
  function checkUserLogin() {
    // Check cookies first
    const cookieValue = document.cookie
      .split('; ')
      .find(row => row.startsWith('currentUser='))
      ?.split('=')[1];
    
    if (cookieValue) {
      return JSON.parse(cookieValue);
    }
    
    // Check session storage
    const sessionUser = sessionStorage.getItem('currentUser');
    if (sessionUser) {
      return JSON.parse(sessionUser);
    }
    
    return null;
  }

  // Handle Address Management
  const addAddressBtn = document.getElementById('addAddressBtn');
  if (addAddressBtn) {
    addAddressBtn.addEventListener('click', function() {
      alert('Add new address functionality');
    });
  }
});
