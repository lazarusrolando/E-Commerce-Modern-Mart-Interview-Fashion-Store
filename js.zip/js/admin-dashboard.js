import headerFunc from "./header.js"
import productFunc from "./product.js"
import searchFunc from "./search.js"
import bcrypt from "bcryptjs"

// Admin Management
let currentUser = null;
const admins = JSON.parse(localStorage.getItem('admins')) || [];
const loggedInAdmins = JSON.parse(sessionStorage.getItem('loggedInAdmins')) || [];

// Update admin counts
function updateAdminCounts() {
  const totalAdmins = admins.length;
  const registeredAdmins = admins.filter(admin => admin.status === 'active').length;
  const loggedInCount = loggedInAdmins.length;

  // Update counts in both dashboard and admins page
  document.getElementById('registeredAdminsCount').textContent = registeredAdmins;
  document.getElementById('loggedInAdminsCount').textContent = loggedInCount;
}


// Initialize dashboard
function initDashboard() {
  const dashboardTabs = document.querySelectorAll('.dashboard-tab');
  dashboardTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      dashboardTabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      const tabId = tab.getAttribute('data-tab');
      const tabContents = document.querySelectorAll('.tab-content');
      tabContents.forEach(content => content.classList.remove('active'));
      document.getElementById(`${tabId}Tab`).classList.add('active');
    });
  });
}

// Handle login
function handleLogin(event) {
  event.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  const admin = checkAdminLogin();
  if (admin && bcrypt.compareSync(password, admin.password)) {
    document.getElementById('adminName').textContent = admin.name;
    
    // Update logged-in admins
    if (!loggedInAdmins.includes(admin.id)) {
      loggedInAdmins.push(admin.id);
      sessionStorage.setItem('loggedInAdmins', JSON.stringify(loggedInAdmins));
    }
    updateAdminCounts();


    // Update user statistics
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const totalUsers = users.length;
    const activeUsers = users.filter(u => u.status === 'active').length;
    
    document.getElementById('totalUsersCount').textContent = totalUsers;
    document.getElementById('activeUsersCount').textContent = activeUsers;

    document.getElementById('userDashboard').style.display = 'block';
    document.querySelectorAll('.account-column').forEach(col => col.style.display = 'none');
  } else {
    alert('Invalid login credentials');
  }
}

// Handle registration
function handleRegister(event) {
  event.preventDefault();
  document.getElementById('userDashboard').style.display = 'block';
  document.querySelectorAll('.account-column').forEach(col => col.style.display = 'none');
}

// Initialize account functionality
function initAccount() {
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');
  
  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }
  
  if (registerForm) {
    registerForm.addEventListener('submit', handleRegister);
  }
  
  initDashboard();
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
  initAccount();
  updateAdminCounts();


  // Set admin name in profile page
  if (window.location.pathname.includes('profile.html')) {
    const admin = checkAdminLogin();
    const profileName = document.getElementById('profile-name');
    if (profileName && admin) {
      profileName.textContent = admin.name;
    }
  }
});

// Product Management
(async function () {
    const products = await fetch("js/data.json")
    const data = await products.json()
    data ? localStorage.setItem("products", JSON.stringify(data)) : []
    productFunc(data)
    searchFunc(data)
})()

// Cart Management
const cartItem = document.querySelector(".header-cart-count")
cartItem.innerHTML = localStorage.getItem("cart")
    ? JSON.parse(localStorage.getItem("cart")).length
    : "0"

// Modal Dialog
const modal = document.querySelector(".modal-dialog")
const modalContent = document.querySelector(".modal-dialog .modal-content")
const btnModalClose = document.querySelector(".modal-dialog .modal-close")

if (btnModalClose) {
    btnModalClose.addEventListener("click", () => {
        modal.classList.remove("show")
    })
}

if (modal) {
    document.addEventListener("click", (e) => {
        if (!e.composedPath().includes(modalContent)) {
            modal.classList.remove("show")
        }
    })
}

if (modal) {
    setTimeout(() => {
        modal.classList.add("show")
    }, 3000)
}

// Profile Dropdown Interaction
document.addEventListener('DOMContentLoaded', function() {
  // Toggle profile dropdown
  const profile = document.querySelector('.user-profile');
  if (profile) {
      profile.addEventListener('click', function(e) {
          e.stopPropagation();
          const dropdown = this.querySelector('.dropdown');
          dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
      });
  }

  // Close dropdown when clicking outside
  document.addEventListener('click', function() {
      const dropdowns = document.querySelectorAll('.user-profile .dropdown');
      dropdowns.forEach(dropdown => {
          dropdown.style.display = 'none';
      });
  });

  // Profile Picture Upload
  const profilePictureInput = document.getElementById('profile-picture');
  if (profilePictureInput) {
      profilePictureInput.addEventListener('change', function(e) {
          const file = e.target.files[0];
          if (file) {
              const reader = new FileReader();
              reader.onload = function(e) {
                  const img = document.querySelector('.profile-picture img');
                  img.src = e.target.result;
              }
              reader.readAsDataURL(file);
          }
      });
  }

  // Profile Form Submission
  const profileForm = document.querySelector('.profile-form');
  if (profileForm) {
      profileForm.addEventListener('submit', function(e) {
          e.preventDefault();
          // Add form submission logic here
          alert('Profile updated successfully!');
      });
  }

  // Settings Form Submission
  const settingsForm = document.querySelector('.settings-form');
  if (settingsForm) {
      settingsForm.addEventListener('submit', function(e) {
          e.preventDefault();
          
          const formData = new FormData(settingsForm);
          const settings = {
              storeName: formData.get('storeName'),
              currency: formData.get('currency'),
              paymentMethods: {
                  paypal: settingsForm.querySelector('input[type="checkbox"][value="paypal"]').checked,
                  stripe: settingsForm.querySelector('input[type="checkbox"][value="stripe"]').checked
              },
              security: {
                  twoFactor: formData.get('twoFactor'),
                  sessionTimeout: formData.get('sessionTimeout')
              }
          };

          // Save settings to localStorage
          localStorage.setItem('settings', JSON.stringify(settings));
          alert('Settings saved successfully!');
      });
  }

  // Load saved settings
  const savedSettings = localStorage.getItem('settings');
  if (savedSettings && settingsForm) {
      const settings = JSON.parse(savedSettings);
      settingsForm.querySelector('input[name="storeName"]').value = settings.storeName;
      settingsForm.querySelector('select[name="currency"]').value = settings.currency;
      settingsForm.querySelector('input[type="checkbox"][value="paypal"]').checked = settings.paymentMethods.paypal;
      settingsForm.querySelector('input[type="checkbox"][value="stripe"]').checked = settings.paymentMethods.stripe;
      settingsForm.querySelector('select[name="twoFactor"]').value = settings.security.twoFactor;
      settingsForm.querySelector('input[name="sessionTimeout"]').value = settings.security.sessionTimeout;
  }

  // Active Navigation Link
  const currentPage = window.location.pathname.split('/').pop();
  const navLinks = document.querySelectorAll('.dashboard-header nav a');
  navLinks.forEach(link => {
      if (link.getAttribute('href') === currentPage) {
          link.classList.add('active');
      }
  });
});

// Responsive UI Handling
document.addEventListener('DOMContentLoaded', function() {
  const updateCartBtn = document.querySelector('.update-coupon .btn');
  
  function updateCartButtonDisplay() {
    if (window.innerWidth < 768) {
      updateCartBtn.innerHTML = '<i class="bi bi-arrow-clockwise"></i>';
      updateCartBtn.classList.add('icon-only');
    } else {
      updateCartBtn.innerHTML = '<i class="bi bi-arrow-clockwise"></i> Update Cart';
      updateCartBtn.classList.remove('icon-only');
    }
  }

  window.addEventListener('resize', updateCartButtonDisplay);
  updateCartButtonDisplay();
});

document.addEventListener('DOMContentLoaded', function() {
  const productActions = document.querySelectorAll('.product-actions');
  
  function updateButtonDisplay() {
    productActions.forEach(actions => {
      const buttons = actions.querySelectorAll('button');
      if (window.innerWidth < 768) {
        buttons.forEach(button => {
          const icon = button.querySelector('i');
          button.textContent = '';
          button.appendChild(icon);
          button.classList.add('icon-only');
        });
      } else {
        buttons.forEach(button => {
          const icon = button.querySelector('i');
          if (button.classList.contains('btn-edit')) {
            button.textContent = ' Edit';
          } if (button.classList.contains('btn-delete')) {
            button.textContent = ' Delete';
          } if (button.classList.contains('btn-feature')) {
            button.textContent = ' Feature';
          }
          button.prepend(icon);
          button.classList.remove('icon-only');
        });
      }
    });
  }

  window.addEventListener('resize', updateButtonDisplay);
  updateButtonDisplay();
});
