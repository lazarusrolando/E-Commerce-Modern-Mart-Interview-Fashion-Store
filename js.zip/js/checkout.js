const checkoutHandler = {
    init() {
        this.attachEventListeners();
        this.checkLoginStatus();
        this.cartItems = this.getCartItems();
    },

    attachEventListeners() {
        const checkoutButton = document.getElementById('checkout-button');
        if (checkoutButton) {
            checkoutButton.addEventListener('click', this.handleCheckoutClick.bind(this));
        }
    },

    checkLoginStatus() {
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        return isLoggedIn === 'true';
    },

    getCartItems() {
        // Try to get cart items from the main cart storage
        const cart = JSON.parse(localStorage.getItem('cart') || '[]');
        if (cart.length > 0) {
            return cart;
        }
        // Fallback to cartItems if cart is empty
        return JSON.parse(localStorage.getItem('cartItems') || '[]');
    },

    handleCheckoutClick(e) {
        e.preventDefault();

        // Extract cart items from the current page
        const cartRows = document.querySelectorAll('#cart-product tr.cart-item');
        if (cartRows.length === 0) {
            alert("Your cart is empty. Please add items to the cart before proceeding to checkout.");
            return;
        }

        const cartItems = [];
        cartRows.forEach(row => {
            const productNameCell = row.cells[2]; // Third cell contains product name
            const productPriceCell = row.cells[3]; // Fourth cell contains price
            const quantityInput = row.querySelector('.quantity-input');
            
            if (productNameCell && productPriceCell && quantityInput) {
                const productName = productNameCell.innerText;
                const productPrice = productPriceCell.innerText.replace('₹', '').trim();
                const productQuantity = quantityInput.value;
                
                cartItems.push({ 
                    name: productName, 
                    price: parseFloat(productPrice), 
                    quantity: parseInt(productQuantity) 
                });
            }
        });

        // Store cart items for checkout
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        console.log('Cart items stored for checkout:', cartItems);

        if (!this.checkLoginStatus()) {
            // If not logged in, redirect to login page with return URL
            const returnUrl = encodeURIComponent(window.location.pathname);
            window.location.href = `user-account.html?redirect=${returnUrl}`;
            return;
        }

        // If logged in, redirect to user dashboard
        window.location.href = "user-dashboard.html";
    },

    proceedToOrders() {
        // Get cart items (either from current cart or stored checkout cart)
        const cartItems = this.getCartItems();

        if (cartItems.length === 0) {
            alert('Your cart is empty. Please add items before checkout.');
            return;
        }

        // Calculate totals
        const subtotal = this.calculateSubtotal(cartItems);
        const shipping = document.getElementById('fast-cargo')?.checked ? 50 : 0;
        const total = subtotal + shipping;

        // Create order object
        const order = {
            id: Date.now(),
            items: cartItems,
            subtotal: subtotal,
            shipping: shipping,
            total: total,
            status: 'pending',
            date: new Date().toISOString()
        };

        // Save order to localStorage
        const orders = JSON.parse(localStorage.getItem('orders') || '[]');
        orders.push(order);
        localStorage.setItem('orders', JSON.stringify(orders));

        // Store current order ID for reference
        sessionStorage.setItem('currentOrderId', order.id);

        // Redirect to orders page
        window.location.href = 'user-dashboard.html#orders';
    },

    calculateSubtotal(items) {
        return items.reduce((total, item) => {
            const price = item.price?.newPrice || item.price;
            return total + (price * item.quantity);
        }, 0);
    },

    generateInvoice(orderId) {
        const orders = JSON.parse(localStorage.getItem('orders') || '[]');
        const order = orders.find(o => o.id === parseInt(orderId));
        if (order) {
            // Populate the modal with order details
            document.getElementById('invoiceOrderId').textContent = order.id;
            document.getElementById('invoiceDate').textContent = new Date(order.date).toLocaleDateString();
            document.getElementById('invoiceShipTo').textContent = localStorage.getItem('username');
            document.getElementById('invoiceTotal').textContent = `₹${order.total.toFixed(2)}`;
            const invoiceItemList = document.getElementById('invoiceItemList');

            invoiceItemList.innerHTML = order.items.map(item => `
                <li>${item.name} - ₹${(item.price?.newPrice || item.price).toFixed(2)} (Quantity: ${item.quantity})</li>
            `).join('');
            
            // Generate QR code
            const qrcode = new QRCode(document.getElementById("qrcode"), {
                text: `Order ID: ${order.id}`,
                width: 128,
                height: 128,
            });

            // Show the modal
            document.getElementById('invoice-modal').style.display = 'block';
        }
    },

    closeModal() {
        document.getElementById('invoice-modal').style.display = 'none';
        // Clear QR code container
        document.getElementById('qrcode').innerHTML = '';
    }
};

// Initialize checkout handler when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    checkoutHandler.init();

    // If we're on the dashboard page and have a current order
    if (window.location.pathname.includes('user-dashboard.html')) {
        const currentOrderId = sessionStorage.getItem('currentOrderId');
        if (currentOrderId) {
            // Show the order details immediately
            const ordersSection = document.getElementById('orders');
            if (ordersSection) {
                ordersSection.style.display = 'block';
            }
            // Clear the current order ID
            sessionStorage.removeItem('currentOrderId');
        }
    }
});
