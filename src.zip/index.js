const QRCode = require('qrcode');
const fs = require('fs');
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question('Enter the content for the QR code: ', (content) => {
    const fileName = 'qrcode.png';

    QRCode.toFile(fileName, content, {
        color: {
            dark: '#000000',  // Black dots
            light: '#FFFFFF'   // White background
        }
    }, (err) => {
        if (err) {
            console.error('Error generating QR code:', err);
        } else {
            console.log(`QR code generated and saved as ${fileName}`);
        }
        rl.close();
    });
});