document.getElementById('send-button').addEventListener('click', function() {
    const userInput = document.getElementById('user-input').value;
    if (userInput) {
        // Display user message
        const userMessage = document.createElement('div');
        userMessage.textContent = 'You: ' + userInput;
        document.getElementById('chatbot-messages').appendChild(userMessage);
        
        // Clear input field
        document.getElementById('user-input').value = '';

        // Generate bot response
        const botResponse = getBotResponse(userInput);
        
        // Display bot response
        const botMessage = document.createElement('div');
        botMessage.textContent = 'Bot: ' + botResponse;
        document.getElementById('chatbot-messages').appendChild(botMessage);
    }
});

function getBotResponse(input) {
    // Simple predefined responses
    const responses = {
        "hi": "Hello! How can I assist you today?",
        "what is your name?": "I'm your friendly chatbot!",
        "help": "What do you need help with?",
        "bye": "Goodbye! Have a great day!"
    };
    return responses[input.toLowerCase()] || "I'm sorry, I don't understand that.";
}
