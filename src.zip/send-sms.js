const express = require('express');
const twilio = require('twilio');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
app.use(express.static(path.join(__dirname)));


const port = 3000;

// Twilio credentials
const accountSid = process.env.accountSid;
const authToken = process.env.authToken;
const client = twilio(accountSid, authToken);

app.use(bodyParser.json());

app.post('/send-sms', (req, res) => {
    const { phoneNumber, code } = req.body;

    client.messages
        .create({
            body: `Your verification code is: ${code}`,
            from: '+13512072189',
            to: phoneNumber
        })
        .then(message => {
            console.log(`Message sent: ${message.sid}`);
            res.status(200).send('SMS sent successfully');
        })
        .catch(error => {
            console.error('Error sending SMS:', error);
            res.status(500).send('Error sending SMS');
        });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
    console.log('Serving static files from the "public" directory');
});
